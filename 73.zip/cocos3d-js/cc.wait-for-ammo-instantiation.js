System.register(["./ammo-instantiated-98540b79.js"],(function(t){"use strict";return{setters:[function(e){t("default",e.w)}],execute:function(){}}}));
